package com.cg.bookmydoctor.dto;

import java.io.Serializable;
import java.util.Date;

public class AvailabilityDates implements Serializable{

	private static final long serialVersionUID = 1L;
	private int availabilityId;
	private Doctor doctor;
	private Date fromDate;
	private Date toDate;
	
	
	
}
