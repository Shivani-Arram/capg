package com.cg.bookmydoctor.dto;

public class User {
	private int userId;
	private String userName;
	private String password;
	private String role; // admin//doctor //patient
}
