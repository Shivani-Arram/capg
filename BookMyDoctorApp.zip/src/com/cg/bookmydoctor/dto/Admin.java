package com.cg.bookmydoctor.dto;

public class Admin {

	private int adminId;
	private String email;
	private String password;

}
