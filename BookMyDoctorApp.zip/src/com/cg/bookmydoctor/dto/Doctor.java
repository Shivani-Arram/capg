package com.cg.bookmydoctor.dto;


public class Doctor {

	private int doctorId;
	private String doctorName;
	private String speciality;
	private String location;
	private String hospitalName;
	private long mobileNo;
	private String email;
	private String password;
	private double chargesPerVisit;
}
