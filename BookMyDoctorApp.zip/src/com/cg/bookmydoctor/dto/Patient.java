package com.cg.bookmydoctor.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class Patient implements Serializable {

private int patientId;
private String patientName;
private long mobileNo;
private String email;
private String password;
private String bloodGroup;
private String gender;
private int age;
private String address;
}
