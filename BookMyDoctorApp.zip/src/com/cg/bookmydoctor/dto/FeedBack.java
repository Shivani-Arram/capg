package com.cg.bookmydoctor.dto;

public class FeedBack {
	
	private int ratingId;
	private Patient patient;
	private Doctor doctor;
	private int rating;
	private String feedback;

}
